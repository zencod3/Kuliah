package Kuliah.StrukturData.Modul3.TugasPraktikum;

import java.util.*; // Import library java.util untuk menggunakan kelas Stack dan Scanner

public class Tugas1 { // Deklarasi kelas Tugas1
    public static void main(String[] args) { // Deklarasi method main
        Scanner input = new Scanner(System.in); // Membuat objek Scanner untuk input dari pengguna
        System.out.print("Masukkan sebuah string: "); // Meminta pengguna untuk memasukkan sebuah string
        String inputString = input.nextLine(); // Membaca input string dari pengguna

        Stack<Character> stack = new Stack<Character>(); // Membuat objek Stack untuk menampung karakter string
        for (int i = 0; i < inputString.length(); i++) { // Loop untuk memasukkan setiap karakter string ke dalam stack
            stack.push(inputString.charAt(i)); // Memasukkan setiap karakter string ke dalam stack menggunakan metode push()
        }

        StringBuilder reversedString = new StringBuilder(); // Membuat objek StringBuilder untuk menampung string terbalik
        while (!stack.isEmpty()) { // Loop untuk mengambil setiap karakter dari stack dan menambahkannya ke dalam objek StringBuilder sampai stack kosong
            reversedString.append(stack.pop()); // Mengambil setiap karakter dari stack menggunakan metode pop() dan menambahkannya ke dalam objek StringBuilder menggunakan metode append()
        }

        System.out.println("String terbalik: " + reversedString.toString()); // Mencetak string terbalik ke layar menggunakan metode toString()
    }
}

