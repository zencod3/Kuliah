package Kuliah.StrukturData.Modul3.TugasPraktikum;

import java.util.Scanner;

import Kuliah.StrukturData.Modul3.TugasPraktikum.ClassKegiatan2.*;

public class Tugas2 {

    public static void main(String[] args) {
        Que queueNo = new Que(); // Inisialisai Class Que menjadi data untuk no urut pelanggan
        Que queueNama = new Que(); // Inisialisai Class Que menjadi data untuk nama pelanggan
        Que queuePesan = new Que(); // Inisialisai Class Que menjadi data untuk pesanan pelanggan
        Scanner scanner = new Scanner(System.in); // Untuk input dari user
        int pilih; // variabel untuk memilih menu
        int noPelanggan = 1; // variabel untuk urutan no pelanggan
        do {
            System.out.println("Menu");
            System.out.println("1. Antrian");
            System.out.println("2. Pesan");
            System.out.println("3. List Pesanan");
            System.out.println("4. Pesanan Selesai");
            System.out.println("5. Keluar");
            System.out.print("Pilih : ");
            pilih = scanner.nextInt(); // inputan dari user akan disimpan ke dalam variabel pilih

            switch (pilih) { // dari variabel pilih akan di cek akan masuk ke case berapa
                case 1:
                    System.out.println("Antrian");
                    System.out.print("Input Nama Pelanggan : ");
                    String namaPelanggan = scanner.next();
                    queueNo.enqueue(Integer.toString(noPelanggan)); // Menyimpan Data No Pelanggan k dalam Class Que
                    queueNama.enqueue(namaPelanggan); // Menyimpan Data Nama Pelanggan k dalam Class Que
                    System.out.println(
                            namaPelanggan + " mendapatkan No Antrian " + noPelanggan + ". Dimohon Menunggu!");
                    noPelanggan++; // Untuk Urutan No Pelanggan
                    break;

                case 2:
                    System.out.println("Pesan");
                    if (!queueNo.isEmpty() && !queueNama.isEmpty()) { // Mengecek Apakah Kosong Atau Tidak
                                                                      // Jika Kosong akan masuk else pada line 81
                        String[][] daftarMenu = { // Membuat Array Multidimensi untuk data pada daftar menu
                                                  // [] yang pertama menunjukan urutan menu
                                                  // [] yang kedua menunjukan daftar menu
                                { "1", "Indomie Goreng Sambal Rica" },
                                { "2", "Indomie Goreng Aceh" },
                                { "3", "Indomie Goreng Original" },
                                { "4", "Indomie Goreng Rendang" },
                                { "5", "Indomie Goreng Cabe Ijo" },
                                { "6", "Indomie Goreng Iga Penyet" },
                                { "7", "Indomie Goreng Hot & Spicy" },
                                { "8", "Nasi putih" },
                                { "9", "Es Teh" },
                                { "10", "Es Jeruk" }
                        };
                        System.out.println("MENU");
                        for (String[] menu : daftarMenu) { // Menampilkan semua data pada array daftar menu
                            System.out.println(menu[0] + "." + menu[1]);
                        }
                        System.out.println("*Note : Untuk Memesan Cukup Input No Contoh : 1,2");
                        String[] arrayPesan; // Digunkan untuk input seperti contoh *Note yang berfungsi jika
                                             // input 1,2 maka akan memilih menu yang ada pada no 1 dan 2
                        System.out.print(
                                queueNama.peek() + " Dengan No Urut " + queueNo.peek() + " Ingin Memesan Apa : ");
                        arrayPesan = scanner.next().split(","); // fungsi split digunakan untuk penanda jika ada , maka
                                                                // inputan ada banyak

                        String pesanan = ""; // Membuat variabel pesanan untuk menampung inputan dari arraypesan yang
                                             // awalnya urutan menu akan menjadi daftar menu
                        for (String nomorMenu : arrayPesan) {
                            boolean menuDitemukan = false; // Membuat varibel dengan nilai false
                            for (String[] menu : daftarMenu) {
                                if (nomorMenu.equals(menu[0])) {// Mengecek nilai dari variabel arraypesan dengan
                                                                // variabel daftarmenu yang urutan menu
                                    pesanan += menu[1] + ", "; // apabila sama maka akan ditambahkan ke dalam varibel
                                                               // pesanan dengan tanda , sebagai pemisah
                                    menuDitemukan = true; // jika pesanan yang dipesan ada pada daftarmenu maka varibel
                                                          // diubah menjadi true
                                    break;
                                }
                            }
                            if (!menuDitemukan) { // mengecek apabila pesanan tidak ada pada daftarmenu
                                System.out.println("Menu dengan nomor urut " + nomorMenu + " tidak ditemukan.");
                            }
                        }
                        System.out.println("Pesanan : [" + pesanan + "\b\b] No Urut " + queueNo.peek()
                                + " Atas Nama " + queueNama.peek());
                        queuePesan.enqueue(pesanan);
                    } else {
                        System.out.println("Belum Ada Antrian");
                    }
                    break;

                case 3:
                    System.out.println("List Pesanan");
                    if (!queueNo.isEmpty() && !queueNama.isEmpty() || !queuePesan.isEmpty()) { // Mengecek apakah
                                                                                               // mempunyai data atau
                                                                                               // tidak
                                                                                               // Jika tidak mempunyai
                                                                                               // data maka akan masuk
                                                                                               // else pada line 101
                        System.out.println("No Urut");
                        queueNo.displayQueue(); // menampilkan data no urut pelanggan
                        System.out.println("Nama Pelanggan");
                        queueNama.displayQueue(); // menampilkan data nama pelanggan
                        if (!queuePesan.isEmpty()) {
                            System.out.println("Pesanan Pelanggan");
                            queuePesan.displayQueue(); // menampilkan data pesanan pelanggan
                        }
                    } else {
                        System.out.println("Belum Ada Antrian!");
                    }
                    break;
                case 4:
                    System.out.println("Pesanan Selesai");
                    queueNo.dequeue(); // menghapus data
                    queueNama.dequeue(); // menghapus data
                    queuePesan.dequeue(); // menghapus data
                    break;

                default:
                    System.out.println("Seng bener Bos!");
                    break;
            }
        } while (pilih != 5); // Jika memilih 5 pada menu maka akan keluar dari perulangan dan program akan selesai
    }
}
