package Kuliah.StrukturData.Modul3.TugasPraktikum;

import java.util.Scanner;

public class Kegiatan1 {
    private static int maxSize;
    private static char[] stackArray;
    private static int top;

    public Kegiatan1(int size) {
        this.maxSize = size;
        this.stackArray = new char[maxSize];
        this.top = -1;
    }

    public static void push(char c) {
        if (top == maxSize - 1) {
            System.out.println("Stack overflow error!");
        } else {
            stackArray[++top] = c;
        }
    }

    public static char pop() {
        if (top == -1) {
            System.out.println("Stack is empty!");
            return ' ';
        } else {
            return stackArray[top--];
        }
    }

    public static String reverse(String input) {
        int inputLength = input.length();
        String reversedString = "";

        for (int i = 0; i < inputLength; i++) {
            char c = input.charAt(i);
            push(c);
        }

        while (top != -1) {
            char c = pop();
            reversedString += c;
        }

        return reversedString;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); // Membuat objek Scanner untuk input dari pengguna
        System.out.print("Masukkan sebuah string: "); // Meminta pengguna untuk memasukkan sebuah string
        String inputString = input.nextLine(); // Membaca input string dari pengguna
        reverse(inputString);
    }
}
