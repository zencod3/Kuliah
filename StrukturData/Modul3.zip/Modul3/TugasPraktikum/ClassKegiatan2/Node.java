package Kuliah.StrukturData.Modul3.TugasPraktikum.ClassKegiatan2;

public class Node {
    String data;
    Node next;

    public Node(String data) {
        this.data = data;
        next = null;
    }

    public Node(String no, String data2) {
    }
}
